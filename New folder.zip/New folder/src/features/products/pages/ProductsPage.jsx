// src/features/products/pages/ProductsPage.jsx
//
// CHANGES IN THIS VERSION:
//   ✅ Added ExportButton with PRODUCT_CSV_COLUMNS to the PageHeader action slot
//   All other logic, layout, styles unchanged.
//
// PREVIOUS FIXES RETAINED:
//   ✅ FIX A — Tax Rate changed from dropdown to number textbox
//   ✅ FIX B — Back button wired up (← Back to Dashboard via useNavigate)

import { useState, useMemo } from 'react'
import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { z } from 'zod'
import { useQuery } from '@tanstack/react-query'
import { useNavigate } from 'react-router-dom'

import {
  Button,
  Table,
  Badge,
  Modal,
  ConfirmDialog,
  PageHeader,
  Pagination,
  FormField,
  Input,
  SearchBar,
  ExportButton,
  selectStyle,
} from '../../../shared/components'

import { PRODUCT_CSV_COLUMNS }  from '../../../shared/utils/csvExport'
import { usePermissions }       from '../../../shared/hooks/usePermissions'
import useAuthStore              from '../../../store/authStore'
import { formatDate }            from '../../../shared/utils/formatDate'
import { fetchCategories }       from '../../categories/api/categoriesApi'

import {
  useProducts,
  useCreateProduct,
  useUpdateProduct,
  useDeleteProduct,
} from '../hooks/useProducts'

// ── Unit options ───────────────────────────────────────────────────────────────
const UNITS = ['pcs', 'kg', 'g', 'litre', 'ml', 'box', 'pack', 'pair', 'set', 'dozen']

// ── Zod schema (create) ───────────────────────────────────────────────────────
const createSchema = z.object({
  prod_name:            z.string().min(1, 'Product name is required').max(100).trim(),
  prod_sell_price:      z.coerce.number({ invalid_type_error: 'Enter a valid price' }).min(0, 'Cannot be negative'),
  prod_cost_price:      z.coerce.number({ invalid_type_error: 'Enter a valid price' }).min(0, 'Cannot be negative'),
  prod_stock_qty:       z.coerce.number().int().min(0, 'Cannot be negative').default(0),
  prod_low_stock_alert: z.coerce.number().int().min(0, 'Cannot be negative').default(10),
  tax_rate:             z.coerce.number().min(0, 'Cannot be negative').max(100, 'Max 100%').default(0),
  tax_code:             z.string().max(50).optional().or(z.literal('')),
  barcode:              z.string().max(100).optional().or(z.literal('')),
  unit:                 z.string().default('pcs'),
  category_id:          z.string().optional().or(z.literal('')),
})

// ── Zod schema (edit — stock qty excluded) ────────────────────────────────────
const editSchema = z.object({
  prod_name:            z.string().min(1, 'Product name is required').max(100).trim(),
  prod_sell_price:      z.coerce.number({ invalid_type_error: 'Enter a valid price' }).min(0, 'Cannot be negative'),
  prod_cost_price:      z.coerce.number({ invalid_type_error: 'Enter a valid price' }).min(0, 'Cannot be negative'),
  prod_low_stock_alert: z.coerce.number().int().min(0, 'Cannot be negative').default(10),
  tax_rate:             z.coerce.number().min(0, 'Cannot be negative').max(100, 'Max 100%').default(0),
  tax_code:             z.string().max(50).optional().or(z.literal('')),
  barcode:              z.string().max(100).optional().or(z.literal('')),
  unit:                 z.string().default('pcs'),
  category_id:          z.string().optional().or(z.literal('')),
})

// ── Category dropdown ─────────────────────────────────────────────────────────
function useCategoryOptions() {
  const { data } = useQuery({
    queryKey: ['categories', 'list', 1],
    queryFn:  () => fetchCategories({ page: 1, limit: 100 }),
    staleTime: 60_000,
  })
  return data?.items ?? []
}

// ── Date range filter bar ─────────────────────────────────────────────────────
function DateRangeFilter({ from, to, onChange }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 8, flexWrap: 'wrap' }}>
      <span style={{
        fontSize: 12, fontWeight: 600, color: 'var(--text-muted)',
        letterSpacing: '0.04em', textTransform: 'uppercase', whiteSpace: 'nowrap',
      }}>
        Last Updated
      </span>
      <input type="date" value={from} onChange={e => onChange('from', e.target.value)} style={dateInputStyle} />
      <span style={{ fontSize: 12, color: 'var(--text-muted)' }}>to</span>
      <input type="date" value={to}   onChange={e => onChange('to',   e.target.value)} style={dateInputStyle} />
      {(from || to) && (
        <button
          onClick={() => { onChange('from', ''); onChange('to', '') }}
          style={{
            background: 'none', border: 'none', cursor: 'pointer',
            fontSize: 11.5, color: 'var(--accent-600)', fontWeight: 600,
            padding: '2px 6px',
            fontFamily: 'var(--font-sans, "Plus Jakarta Sans", sans-serif)',
          }}
        >
          Clear
        </button>
      )}
    </div>
  )
}

const dateInputStyle = {
  padding: '6px 10px',
  background: 'var(--bg-card)',
  border: '1.5px solid var(--border)',
  borderRadius: 8,
  fontSize: 12.5,
  color: 'var(--text-primary)',
  fontFamily: 'var(--font-sans, "Plus Jakarta Sans", sans-serif)',
  outline: 'none',
  cursor: 'pointer',
}

// ── Add Product Form ──────────────────────────────────────────────────────────
function AddProductForm({ onSubmit, onClose, isPending, categories }) {
  const { register, handleSubmit, formState: { errors } } = useForm({
    resolver: zodResolver(createSchema),
    defaultValues: {
      prod_stock_qty:       0,
      prod_low_stock_alert: 10,
      tax_rate:             0,
      unit:                 'pcs',
    },
  })

  return (
    <form onSubmit={handleSubmit(onSubmit)}>
      <FormField label="Product Name" error={errors.prod_name} required style={{ marginBottom: 16 }}>
        <Input placeholder="e.g. Basmati Rice 5kg" autoFocus {...register('prod_name')} />
      </FormField>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12, marginBottom: 16 }}>
        <FormField label="Selling Price" error={errors.prod_sell_price} required>
          <Input type="number" step="0.01" placeholder="0.00" {...register('prod_sell_price')} />
        </FormField>
        <FormField label="Cost Price" error={errors.prod_cost_price} required>
          <Input type="number" step="0.01" placeholder="0.00" {...register('prod_cost_price')} />
        </FormField>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12, marginBottom: 16 }}>
        <FormField label="Opening Stock Qty" error={errors.prod_stock_qty}>
          <Input type="number" step="1" placeholder="0" {...register('prod_stock_qty')} />
        </FormField>
        <FormField label="Low Stock Alert" error={errors.prod_low_stock_alert} helper="Alert when stock falls below this">
          <Input type="number" step="1" placeholder="10" {...register('prod_low_stock_alert')} />
        </FormField>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12, marginBottom: 16 }}>
        <FormField label="Category" error={errors.category_id}>
          <select {...register('category_id')} style={selectStyle}>
            <option value="">— No category —</option>
            {categories.map(c => (
              <option key={c.category_id} value={c.category_id}>{c.category_name}</option>
            ))}
          </select>
        </FormField>
        <FormField label="Unit" error={errors.unit}>
          <select {...register('unit')} style={selectStyle}>
            {UNITS.map(u => <option key={u} value={u}>{u}</option>)}
          </select>
        </FormField>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12, marginBottom: 16 }}>
        <FormField label="Tax Rate (%)" error={errors.tax_rate} helper="e.g. 0, 5, 7.5, 10, 18, 20">
          <Input type="number" step="0.01" min="0" max="100" placeholder="e.g. 18" {...register('tax_rate')} />
        </FormField>
        <FormField label="Tax Code (HSN / SAC)" error={errors.tax_code} helper="Optional">
          <Input placeholder="e.g. 1006" {...register('tax_code')} />
        </FormField>
      </div>

      <FormField label="Barcode" error={errors.barcode} helper="Optional" style={{ marginBottom: 8 }}>
        <Input placeholder="e.g. 8901234567890" {...register('barcode')} />
      </FormField>

      <Modal.Footer>
        <Button variant="ghost" onClick={onClose} disabled={isPending}>Cancel</Button>
        <Button type="submit" variant="primary" loading={isPending}>Create Product</Button>
      </Modal.Footer>
    </form>
  )
}

// ── Edit Product Form ─────────────────────────────────────────────────────────
function EditProductForm({ defaultValues, onSubmit, onClose, isPending, categories }) {
  const { register, handleSubmit, formState: { errors } } = useForm({
    resolver: zodResolver(editSchema),
    defaultValues,
  })

  return (
    <form onSubmit={handleSubmit(onSubmit)}>
      <div style={{
        background: 'var(--bg-page)',
        border: '1.5px solid var(--border)',
        borderRadius: 10,
        padding: '10px 14px',
        marginBottom: 16,
        fontSize: 12.5,
        color: 'var(--text-muted)',
        display: 'flex',
        alignItems: 'center',
        gap: 8,
      }}>
        <span>📦</span>
        <span>
          Current stock: <strong style={{ color: 'var(--text-primary)' }}>
            {defaultValues._stock_qty ?? '—'} {defaultValues.unit ?? 'pcs'}
          </strong>
          &nbsp;— to adjust stock, use the <strong>Stock</strong> page.
        </span>
      </div>

      <FormField label="Product Name" error={errors.prod_name} required style={{ marginBottom: 16 }}>
        <Input placeholder="e.g. Basmati Rice 5kg" autoFocus {...register('prod_name')} />
      </FormField>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12, marginBottom: 16 }}>
        <FormField label="Selling Price" error={errors.prod_sell_price} required>
          <Input type="number" step="0.01" placeholder="0.00" {...register('prod_sell_price')} />
        </FormField>
        <FormField label="Cost Price" error={errors.prod_cost_price} required>
          <Input type="number" step="0.01" placeholder="0.00" {...register('prod_cost_price')} />
        </FormField>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12, marginBottom: 16 }}>
        <FormField label="Low Stock Alert" error={errors.prod_low_stock_alert} helper="Alert when stock falls below this">
          <Input type="number" step="1" placeholder="10" {...register('prod_low_stock_alert')} />
        </FormField>
        <FormField label="Unit" error={errors.unit}>
          <select {...register('unit')} style={selectStyle}>
            {UNITS.map(u => <option key={u} value={u}>{u}</option>)}
          </select>
        </FormField>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12, marginBottom: 16 }}>
        <FormField label="Category" error={errors.category_id}>
          <select {...register('category_id')} style={selectStyle}>
            <option value="">— No category —</option>
            {categories.map(c => (
              <option key={c.category_id} value={c.category_id}>{c.category_name}</option>
            ))}
          </select>
        </FormField>
        <FormField label="Tax Rate (%)" error={errors.tax_rate} helper="e.g. 0, 5, 7.5, 10, 18, 20">
          <Input type="number" step="0.01" min="0" max="100" placeholder="e.g. 18" {...register('tax_rate')} />
        </FormField>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12, marginBottom: 8 }}>
        <FormField label="Tax Code (HSN / SAC)" error={errors.tax_code} helper="Optional">
          <Input placeholder="e.g. 1006" {...register('tax_code')} />
        </FormField>
        <FormField label="Barcode" error={errors.barcode} helper="Optional">
          <Input placeholder="e.g. 8901234567890" {...register('barcode')} />
        </FormField>
      </div>

      <Modal.Footer>
        <Button variant="ghost" onClick={onClose} disabled={isPending}>Cancel</Button>
        <Button type="submit" variant="primary" loading={isPending}>Save Changes</Button>
      </Modal.Footer>
    </form>
  )
}

// ── Currency formatter ─────────────────────────────────────────────────────────
function fmt(num) {
  if (num == null) return '—'
  return Number(num).toLocaleString('en-IN', {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  })
}

// ── Main Page ──────────────────────────────────────────────────────────────────
export default function ProductsPage() {
  const { can }   = usePermissions()
  const canManage = can('products.edit')
  const categories = useCategoryOptions()

  const profile = useAuthStore(s => s.profile)
  const isAdmin = profile?.is_admin === true

  const navigate = useNavigate()

  const {
    products,
    pagination,
    page,
    setPage,
    search,
    setSearch,
    isLoading,
    isError,
  } = useProducts()

  const [sortKey, setSortKey] = useState(null)
  const [sortDir, setSortDir] = useState('asc')

  function handleSort(key) {
    if (sortKey === key) {
      setSortDir(d => d === 'asc' ? 'desc' : 'asc')
    } else {
      setSortKey(key)
      setSortDir('asc')
    }
  }

  const [dateFrom, setDateFrom] = useState('')
  const [dateTo,   setDateTo]   = useState('')

  function handleDateChange(field, value) {
    if (field === 'from') setDateFrom(value)
    else                  setDateTo(value)
  }

  const displayRows = useMemo(() => {
    let rows = [...products]

    if (dateFrom) {
      const from = new Date(dateFrom)
      from.setHours(0, 0, 0, 0)
      rows = rows.filter(r => r.updated_at && new Date(r.updated_at) >= from)
    }
    if (dateTo) {
      const to = new Date(dateTo)
      to.setHours(23, 59, 59, 999)
      rows = rows.filter(r => r.updated_at && new Date(r.updated_at) <= to)
    }

    if (sortKey) {
      rows.sort((a, b) => {
        let valA = a[sortKey]
        let valB = b[sortKey]

        if (sortKey === 'updated_at') {
          valA = valA ? new Date(valA).getTime() : 0
          valB = valB ? new Date(valB).getTime() : 0
          return sortDir === 'asc' ? valA - valB : valB - valA
        }

        if (typeof valA === 'number' || !isNaN(Number(valA))) {
          valA = Number(valA ?? 0)
          valB = Number(valB ?? 0)
          return sortDir === 'asc' ? valA - valB : valB - valA
        }

        valA = String(valA ?? '').toLowerCase()
        valB = String(valB ?? '').toLowerCase()
        if (valA < valB) return sortDir === 'asc' ? -1 :  1
        if (valA > valB) return sortDir === 'asc' ?  1 : -1
        return 0
      })
    }

    return rows
  }, [products, sortKey, sortDir, dateFrom, dateTo])

  const { mutate: createProduct, isPending: isCreating } = useCreateProduct()
  const { mutate: updateProduct, isPending: isUpdating } = useUpdateProduct()
  const { mutate: deleteProduct, isPending: isDeleting } = useDeleteProduct()

  const [showAdd,      setShowAdd]      = useState(false)
  const [editTarget,   setEditTarget]   = useState(null)
  const [deleteTarget, setDeleteTarget] = useState(null)

  function handleCreate(data) {
    const payload = {
      ...data,
      tax_code:    data.tax_code    || null,
      barcode:     data.barcode     || null,
      category_id: data.category_id || null,
    }
    createProduct(payload, { onSuccess: () => setShowAdd(false) })
  }

  function handleUpdate(data) {
    const payload = {
      ...data,
      tax_code:    data.tax_code    || null,
      barcode:     data.barcode     || null,
      category_id: data.category_id || null,
    }
    updateProduct(
      { id: editTarget.prod_id, payload },
      { onSuccess: () => setEditTarget(null) }
    )
  }

  function handleDelete() {
    deleteProduct(deleteTarget.prod_id, {
      onSuccess: () => setDeleteTarget(null),
    })
  }

  const columns = [
    {
      key:      'prod_name',
      label:    'Product',
      sortable: true,
      render: (row) => (
        <div>
          <div style={{ fontWeight: 600, color: 'var(--text-primary)', fontSize: 13.5 }}>
            {row.prod_name}
          </div>
          {row.barcode && (
            <div style={{ fontSize: 11.5, color: 'var(--text-muted)', marginTop: 2 }}>
              Barcode: {row.barcode}
            </div>
          )}
        </div>
      ),
    },
    {
      key:      'category_name',
      label:    'Category',
      sortable: true,
      width:    130,
      render: (row) => (
        row.category_name
          ? <Badge variant="neutral" label={row.category_name} />
          : <span style={{ fontSize: 12, color: 'var(--text-muted)' }}>—</span>
      ),
    },
    {
      key:      'prod_stock_qty',
      label:    'Stock',
      sortable: true,
      width:    90,
      render: (row) => {
        const isLow = row.prod_stock_qty <= row.prod_low_stock_alert
        return (
          <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
            <span style={{ fontWeight: 600, fontSize: 13.5, color: isLow ? '#EF4444' : 'var(--text-primary)' }}>
              {row.prod_stock_qty}
            </span>
            <span style={{ fontSize: 11.5, color: 'var(--text-muted)' }}>{row.unit ?? 'pcs'}</span>
            {isLow && <Badge variant="danger" label="Low" dot />}
          </div>
        )
      },
    },
    {
      key:      'prod_sell_price',
      label:    'Sell Price',
      sortable: true,
      width:    110,
      render: (row) => (
        <span style={{ fontWeight: 600, fontSize: 13.5, color: 'var(--text-primary)' }}>
          ₹{fmt(row.prod_sell_price)}
        </span>
      ),
    },
    ...(isAdmin
      ? [
          {
            key:      'prod_cost_price',
            label:    'Cost Price',
            sortable: true,
            width:    110,
            render: (row) => (
              <span style={{ fontSize: 13, color: 'var(--text-secondary)' }}>
                ₹{fmt(row.prod_cost_price)}
              </span>
            ),
          },
          {
            key:      'prod_profit',
            label:    'Profit',
            sortable: true,
            width:    100,
            render: (row) => {
              const profit = row.prod_profit
              const isNeg  = Number(profit) < 0
              return (
                <span style={{ fontSize: 13, fontWeight: 600, color: isNeg ? '#EF4444' : '#10B981' }}>
                  {isNeg ? '−' : '+'}₹{fmt(Math.abs(profit))}
                </span>
              )
            },
          },
        ]
      : []),
    {
      key:      'tax_rate',
      label:    'Tax',
      sortable: true,
      width:    70,
      render: (row) => (
        <span style={{ fontSize: 12.5, color: 'var(--text-muted)' }}>
          {row.tax_rate ?? 0}%
        </span>
      ),
    },
    {
      key:      'updated_at',
      label:    'Last Updated',
      sortable: true,
      width:    110,
      render: (row) => (
        <span style={{ fontSize: 12.5, color: 'var(--text-muted)' }}>
          {row.updated_at ? formatDate(row.updated_at) : '—'}
        </span>
      ),
    },
    {
      key:      'last_updated_by',
      label:    'Last Updated By',
      sortable: false,
      width:    140,
      render: (row) => (
        row.last_updated_by
          ? (
            <span style={{ fontSize: 12.5, color: 'var(--text-secondary)', fontWeight: 500 }}>
              {row.last_updated_by}
            </span>
          )
          : <span style={{ fontSize: 12, color: 'var(--text-muted)' }}>—</span>
      ),
    },
    ...(canManage
      ? [{
          key:   'actions',
          label: '',
          width: 130,
          render: (row) => (
            <div style={{ display: 'flex', gap: 8, justifyContent: 'flex-end' }}>
              <Button variant="secondary" size="sm" onClick={(e) => { e.stopPropagation(); setEditTarget(row) }}>
                Edit
              </Button>
              <Button variant="danger" size="sm" onClick={(e) => { e.stopPropagation(); setDeleteTarget(row) }}>
                Delete
              </Button>
            </div>
          ),
        }]
      : []),
  ]

  const activeSearch     = search.trim().length > 0
  const activeDateFilter = dateFrom || dateTo

  return (
    <>
      <PageHeader
        title="Products"
        subtitle="Manage your product catalogue, prices, and stock alerts"
        back
        onBack={() => navigate('/dashboard')}
        action={
          <div style={{ display: 'flex', gap: 10, alignItems: 'center' }}>
            {/* ADDED: Export CSV button — shows current filtered/searched list */}
            <ExportButton
              data={displayRows}
              filename="products"
              columns={PRODUCT_CSV_COLUMNS}
            />
            {canManage && (
              <Button
                variant="primary"
                leftIcon={<span style={{ fontSize: 16, lineHeight: 1 }}>+</span>}
                onClick={() => setShowAdd(true)}
              >
                Add Product
              </Button>
            )}
          </div>
        }
      />

      {/* Toolbar */}
      <div style={{
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        marginBottom: 20,
        gap: 12,
        flexWrap: 'wrap',
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12, flexWrap: 'wrap' }}>
          <SearchBar
            value={search}
            onChange={setSearch}
            onSearch={setSearch}
            placeholder="Search by product or category…"
            width="280px"
          />
          <span style={{ fontSize: 12.5, color: 'var(--text-muted)', fontWeight: 500 }}>
            {displayRows.length} product{displayRows.length !== 1 ? 's' : ''}
            {(activeSearch || activeDateFilter) && ' (filtered)'}
          </span>
        </div>
        <DateRangeFilter from={dateFrom} to={dateTo} onChange={handleDateChange} />
      </div>

      {isError && (
        <div style={{
          background: 'var(--danger-bg)', border: '1px solid var(--danger-border)',
          borderRadius: 12, padding: '13px 18px', color: 'var(--danger-text)',
          fontSize: 13.5, marginBottom: 24, fontWeight: 500,
        }}>
          ⚠️ Could not load products. Check that the backend is running and refresh.
        </div>
      )}

      <div style={{ overflowX: 'auto', width: '100%' }}>
        <Table
          columns={columns}
          rows={displayRows}
          loading={isLoading}
          rowKey="prod_id"
          sortKey={sortKey}
          sortDir={sortDir}
          onSort={handleSort}
          emptyText={
            activeSearch
              ? 'No products match your search.'
              : activeDateFilter
                ? 'No products in the selected date range.'
                : 'No products yet. Add your first product to get started.'
          }
        />
      </div>

      {!activeSearch && !activeDateFilter && (
        <Pagination pagination={pagination} onPageChange={setPage} />
      )}

      <Modal open={showAdd} onClose={() => setShowAdd(false)} title="Add Product" subtitle="Add a new product to your catalogue" size="lg">
        <AddProductForm
          onSubmit={handleCreate}
          onClose={() => setShowAdd(false)}
          isPending={isCreating}
          categories={categories}
        />
      </Modal>

      <Modal open={Boolean(editTarget)} onClose={() => setEditTarget(null)} title="Edit Product" subtitle={editTarget?.prod_name} size="lg">
        {editTarget && (
          <EditProductForm
            key={editTarget.prod_id}
            defaultValues={{
              prod_name:            editTarget.prod_name,
              prod_sell_price:      editTarget.prod_sell_price,
              prod_cost_price:      editTarget.prod_cost_price,
              prod_low_stock_alert: editTarget.prod_low_stock_alert,
              tax_rate:             editTarget.tax_rate ?? 0,
              tax_code:             editTarget.tax_code  ?? '',
              barcode:              editTarget.barcode   ?? '',
              unit:                 editTarget.unit      ?? 'pcs',
              category_id:          editTarget.category_id ?? '',
              _stock_qty:           editTarget.prod_stock_qty,
            }}
            onSubmit={handleUpdate}
            onClose={() => setEditTarget(null)}
            isPending={isUpdating}
            categories={categories}
          />
        )}
      </Modal>

      <ConfirmDialog
        open={Boolean(deleteTarget)}
        onClose={() => setDeleteTarget(null)}
        onConfirm={handleDelete}
        title={`Delete "${deleteTarget?.prod_name}"?`}
        message="This will permanently deactivate the product. It will no longer appear in sales or purchases. This cannot be undone."
        confirmText="Yes, delete"
        loading={isDeleting}
      />
    </>
  )
}