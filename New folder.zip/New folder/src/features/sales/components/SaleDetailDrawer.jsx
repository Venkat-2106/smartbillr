import React, { useState, useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import {
  XMarkIcon,
  DocumentTextIcon,
  UserIcon,
  CalendarDaysIcon,
  CreditCardIcon,
  BanknotesIcon,
  PrinterIcon,
} from '@heroicons/react/24/outline';
import { fetchSale } from '../api/salesApi';
import { Badge, Button, Spinner } from '../../../shared/components';
import { selectStyle } from '../../../shared/components/FormField';
import { formatCurrency } from '../../../shared/utils/formatCurrency';
import { formatDate }     from '../../../shared/utils/formatDate';
import {
  buildPrintHeader,
  buildPrintWatermark,
  buildPrintFooter,
  triggerPrint,
} from '../../../shared/utils/printUtils';
import useAuthStore from '../../../store/authStore';

const STATUS_VARIANT = { paid: 'success', partial: 'warning', pending: 'danger' };
const STATUS_LABEL   = { paid: 'Paid',    partial: 'Partial', pending: 'Unpaid' };

// ── Payment status badge helper (for print — literal hex, no CSS vars) ────────
function paymentStatusBadge(status) {
  const map = {
    paid:    { color: '#10B981', bg: '#D1FAE5', label: 'Fully Paid' },
    partial: { color: '#F59E0B', bg: '#FEF3C7', label: 'Partially Paid' },
    pending: { color: '#EF4444', bg: '#FEE2E2', label: 'Unpaid' },
  };
  const s = map[status] || { color: '#6b7280', bg: '#f3f4f6', label: status || '—' };
  return `<span style="font-size:11px;font-weight:700;color:${s.color};background:${s.bg};padding:3px 10px;border-radius:20px;letter-spacing:0.03em;">${s.label}</span>`;
}

function buildInvoiceHTML(business, detail, sale, items, cgst, sgst, igst, subtotal, taxTotal, finalAmount, totalPaid, remaining) {
  const payStatus = detail?.sales_payment_status || sale.sales_payment_status || 'pending';
  const payMethod = (detail?.sales_payment_method || sale.sales_payment_method || '—')
    .replace(/_/g, ' ').toUpperCase();

  const gstBreakdown = (cgst > 0 || sgst > 0 || igst > 0) ? `
    <tr><td style="padding:5px 0;color:#6b7280;font-size:12px;">CGST</td><td style="padding:5px 0;text-align:right;font-size:12px;">${formatCurrency(cgst)}</td></tr>
    <tr><td style="padding:5px 0;color:#6b7280;font-size:12px;">SGST</td><td style="padding:5px 0;text-align:right;font-size:12px;">${formatCurrency(sgst)}</td></tr>
    ${igst > 0 ? `<tr><td style="padding:5px 0;color:#6b7280;font-size:12px;">IGST</td><td style="padding:5px 0;text-align:right;font-size:12px;">${formatCurrency(igst)}</td></tr>` : ''}
  ` : '';

  const itemRows = items.map((item, i) => `
    <tr style="background:${i % 2 === 0 ? '#fff' : '#f9fafb'};">
      <td style="padding:9px 8px;font-size:12px;color:#111827;">${item.product_name || 'Product'}</td>
      <td style="padding:9px 8px;text-align:center;font-size:12px;color:#374151;">${item.sale_item_quantity}</td>
      <td style="padding:9px 8px;text-align:right;font-size:12px;color:#374151;">${formatCurrency(item.sale_item_unit_price)}</td>
      <td style="padding:9px 8px;text-align:right;font-size:12px;color:#374151;">${Number(item.item_tax_total) > 0 ? formatCurrency(item.item_tax_total) : '—'}</td>
      <td style="padding:9px 8px;text-align:right;font-size:12px;font-weight:700;color:#111827;">${formatCurrency(item.item_total_with_tax)}</td>
    </tr>
  `).join('');

  return `
    ${buildPrintWatermark()}
    ${buildPrintHeader(business)}

    <!-- Invoice title row -->
    <div style="display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:22px;">
      <div>
        <div style="font-size:26px;font-weight:900;color:#111827;letter-spacing:-1px;line-height:1;">INVOICE</div>
        <div style="font-size:15px;font-weight:700;color:#4F46E5;margin-top:6px;letter-spacing:0.02em;">${sale.invoice_no || ''}</div>
      </div>
      <div style="text-align:right;">
        <div style="font-size:10px;font-weight:700;color:#9ca3af;text-transform:uppercase;letter-spacing:0.07em;margin-bottom:2px;">Invoice Date</div>
        <div style="font-size:13px;font-weight:600;color:#111827;">${formatDate(detail?.sales_created_at || sale.sales_created_at)}</div>
        <div style="margin-top:10px;font-size:10px;font-weight:700;color:#9ca3af;text-transform:uppercase;letter-spacing:0.07em;margin-bottom:4px;">Payment Status</div>
        ${paymentStatusBadge(payStatus)}
        <div style="margin-top:8px;font-size:10px;font-weight:700;color:#9ca3af;text-transform:uppercase;letter-spacing:0.07em;margin-bottom:2px;">Payment Method</div>
        <div style="font-size:12.5px;font-weight:600;color:#374151;">${payMethod}</div>
      </div>
    </div>

    <!-- Bill To -->
    <div style="background:#f9fafb;border:1px solid #e5e7eb;border-radius:8px;padding:14px 18px;margin-bottom:22px;">
      <div style="font-size:10px;font-weight:700;color:#9ca3af;text-transform:uppercase;letter-spacing:0.08em;margin-bottom:6px;">Bill To</div>
      <div style="font-size:15px;font-weight:700;color:#111827;">${detail?.customer_name || sale.customer_name || 'Walk-in Customer'}</div>
    </div>

    <!-- Items table -->
    <table style="width:100%;border-collapse:collapse;margin-bottom:24px;">
      <thead>
        <tr style="border-bottom:2px solid #111827;background:#f9fafb;">
          <th style="text-align:left;padding:9px 8px;font-size:10.5px;font-weight:800;color:#374151;text-transform:uppercase;letter-spacing:0.06em;">Item</th>
          <th style="text-align:center;padding:9px 8px;font-size:10.5px;font-weight:800;color:#374151;text-transform:uppercase;letter-spacing:0.06em;">Qty</th>
          <th style="text-align:right;padding:9px 8px;font-size:10.5px;font-weight:800;color:#374151;text-transform:uppercase;letter-spacing:0.06em;">Rate</th>
          <th style="text-align:right;padding:9px 8px;font-size:10.5px;font-weight:800;color:#374151;text-transform:uppercase;letter-spacing:0.06em;">Tax</th>
          <th style="text-align:right;padding:9px 8px;font-size:10.5px;font-weight:800;color:#374151;text-transform:uppercase;letter-spacing:0.06em;">Total</th>
        </tr>
      </thead>
      <tbody>${itemRows}</tbody>
    </table>

    <!-- Totals block -->
    <div style="display:flex;justify-content:flex-end;margin-bottom:32px;">
      <table style="min-width:280px;">
        <tr><td style="padding:5px 0;color:#6b7280;font-size:12px;">Subtotal</td><td style="padding:5px 0;text-align:right;font-size:12px;">${formatCurrency(subtotal)}</td></tr>
        ${gstBreakdown}
        <tr><td style="padding:5px 0;color:#6b7280;font-size:12px;">Tax Total</td><td style="padding:5px 0;text-align:right;font-size:12px;">${formatCurrency(taxTotal)}</td></tr>
        <tr style="border-top:2px solid #111827;">
          <td style="padding:10px 0 6px;font-size:16px;font-weight:900;color:#111827;">Grand Total</td>
          <td style="padding:10px 0 6px;text-align:right;font-size:16px;font-weight:900;color:#111827;">${formatCurrency(finalAmount)}</td>
        </tr>
        ${totalPaid > 0 ? `<tr><td style="padding:4px 0;color:#10B981;font-size:12px;font-weight:600;">Amount Paid</td><td style="padding:4px 0;text-align:right;font-size:12px;color:#10B981;font-weight:600;">${formatCurrency(totalPaid)}</td></tr>` : ''}
        ${remaining > 0 ? `<tr><td style="padding:4px 0;color:#EF4444;font-size:12.5px;font-weight:700;">Balance Due</td><td style="padding:4px 0;text-align:right;font-size:12.5px;color:#EF4444;font-weight:700;">${formatCurrency(remaining)}</td></tr>` : ''}
      </table>
    </div>

    <!-- Thank you note -->
    <div style="text-align:center;padding:14px;background:#f9fafb;border-radius:8px;font-size:12px;color:#6b7280;font-style:italic;margin-bottom:8px;">
      Thank you for your business!
    </div>

    ${buildPrintFooter()}
  `;
}

export default function SaleDetailDrawer({ sale, onClose, statusMutation }) {
  const [displayStatus, setDisplayStatus] = useState(sale?.sales_payment_status || 'pending');
  const [editingStatus, setEditingStatus] = useState(false);
  const [newStatus,     setNewStatus]     = useState(sale?.sales_payment_status || 'paid');

  const { data: detail, isLoading, isError } = useQuery({
    queryKey: ['sale', sale?.sales_id],
    queryFn:  () => fetchSale(sale.sales_id),
    enabled:  !!sale?.sales_id,
    staleTime: 2 * 60 * 1000,
  });

  // Auto-print after create
  useEffect(() => {
    if (!isLoading && !isError && detail && sale?._autoPrint) {
      const timer = setTimeout(() => handlePrint(), 350);
      return () => clearTimeout(timer);
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isLoading, isError, detail, sale?._autoPrint]);

  if (!sale) return null;

  const subtotal    = detail?.sales_total_amount  ?? sale.sales_total_amount ?? 0;
  const taxTotal    = detail?.tax_total            ?? sale.tax_total          ?? 0;
  const finalAmount = detail?.sales_final_amount   ?? sale.sales_final_amount ?? 0;
  const totalPaid   = detail?.total_paid           ?? 0;
  const remaining   = detail?.remaining_balance    ?? 0;
  const cgst        = detail?.cgst_total           ?? 0;
  const sgst        = detail?.sgst_total           ?? 0;
  const igst        = detail?.igst_total           ?? 0;
  const items       = detail?.items                ?? [];

  function handlePrint() {
    if (!detail && !sale) return;
    const business = useAuthStore.getState().business;
    const html = buildInvoiceHTML(
      business, detail, sale, items, cgst, sgst, igst,
      subtotal, taxTotal, finalAmount, totalPaid, remaining
    );
    triggerPrint(html);
  }

  function handleStatusSave() {
    statusMutation.mutate(
      { id: sale.sales_id, status: newStatus },
      {
        onSuccess: () => {
          setDisplayStatus(newStatus);
          setEditingStatus(false);
        },
      }
    );
  }

  return (
    <>
      {/* Backdrop */}
      <div
        onClick={onClose}
        style={{
          position: 'fixed', inset: 0,
          background: 'rgba(0,0,0,0.35)',
          zIndex: 1000, backdropFilter: 'blur(3px)',
        }}
      />

      {/* Drawer panel — no longer needs invoice-print-area class */}
      <div
        style={{
          position: 'fixed', top: 0, right: 0,
          height: '100vh', width: 520, maxWidth: '95vw',
          background: 'var(--bg-card)',
          borderLeft: '1px solid var(--border)',
          boxShadow: '-8px 0 40px rgba(0,0,0,0.14)',
          zIndex: 1001,
          display: 'flex', flexDirection: 'column',
          overflow: 'hidden',
        }}
      >
        {/* Header */}
        <div style={{
          padding: '22px 24px',
          borderBottom: '1px solid var(--border)',
          display: 'flex', alignItems: 'flex-start',
          justifyContent: 'space-between', gap: 16,
        }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
            <div style={{
              width: 48, height: 48, borderRadius: 14, flexShrink: 0,
              background: 'linear-gradient(135deg, var(--accent-600), var(--accent-500))',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
            }}>
              <DocumentTextIcon style={{ width: 24, height: 24, color: '#fff' }} />
            </div>
            <div>
              <h2 style={{ fontSize: 16, fontWeight: 700, color: 'var(--text-primary)', margin: 0, lineHeight: 1.3 }}>
                {sale.invoice_no || 'Invoice'}
              </h2>
              <p style={{ fontSize: 12, color: 'var(--text-muted)', margin: '3px 0 0' }}>
                Sales Invoice
              </p>
            </div>
          </div>

          <div style={{ display: 'flex', alignItems: 'center', gap: 8, flexShrink: 0 }}>
            <button
              onClick={handlePrint}
              disabled={isLoading || !!isError}
              title="Print Invoice"
              style={{
                display: 'flex', alignItems: 'center', gap: 5,
                background: 'var(--bg-page)', border: '1px solid var(--border)',
                cursor: isLoading || isError ? 'not-allowed' : 'pointer',
                padding: '6px 12px', borderRadius: 8,
                color: isLoading || isError ? 'var(--text-muted)' : 'var(--text-secondary)',
                fontSize: 12.5, fontWeight: 600,
                fontFamily: 'inherit',
                opacity: isLoading || isError ? 0.5 : 1,
                transition: 'background 0.12s',
              }}
              onMouseEnter={e => { if (!isLoading && !isError) e.currentTarget.style.background = 'var(--bg-hover)'; }}
              onMouseLeave={e => { e.currentTarget.style.background = 'var(--bg-page)'; }}
            >
              <PrinterIcon style={{ width: 15, height: 15 }} />
              Print
            </button>
            <button
              onClick={onClose}
              style={{
                background: 'var(--bg-page)', border: '1px solid var(--border)',
                cursor: 'pointer', padding: 6, borderRadius: 8,
                color: 'var(--text-muted)',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
              }}
            >
              <XMarkIcon style={{ width: 18, height: 18 }} />
            </button>
          </div>
        </div>

        {/* Scrollable body */}
        <div style={{ flex: 1, overflowY: 'auto', padding: 24 }}>
          {isLoading ? (
            <div style={{ display: 'flex', justifyContent: 'center', padding: 48 }}>
              <Spinner size="md" />
            </div>
          ) : isError ? (
            <div style={{
              padding: '20px 16px',
              background: 'var(--danger-bg, #FEF2F2)',
              border: '1px solid var(--danger-border, #FCA5A5)',
              borderRadius: 12,
              fontSize: 13.5, color: 'var(--danger-text, #B91C1C)',
              fontWeight: 500, lineHeight: 1.5,
            }}>
              ⚠️ Could not load invoice details. Close and click the invoice again.
            </div>
          ) : (
            <>
              <DrawerSection title="Invoice Details">
                <InfoRow icon={<UserIcon />}         label="Customer"
                  value={detail?.customer_name || sale.customer_name || 'Walk-in'} />
                <InfoRow icon={<CalendarDaysIcon />} label="Invoice Date"
                  value={formatDate(detail?.sales_created_at || sale.sales_created_at)} />
                <InfoRow icon={<CreditCardIcon />}   label="Payment Method"
                  value={(detail?.sales_payment_method || sale.sales_payment_method || '—')
                    .replace('_', ' ').toUpperCase()} />
                <InfoRow
                  icon={<BanknotesIcon />}
                  label="Status"
                  isLast={!editingStatus}
                  value={
                    <Badge
                      variant={STATUS_VARIANT[displayStatus] || 'default'}
                      label={STATUS_LABEL[displayStatus]    || displayStatus}
                      dot
                    />
                  }
                />
                {editingStatus && (
                  <div style={{
                    padding: '12px 14px',
                    borderTop: '1px solid var(--border)',
                    display: 'flex', gap: 8, alignItems: 'center',
                  }}>
                    <select
                      className="sb-select"
                      value={newStatus}
                      onChange={e => setNewStatus(e.target.value)}
                      style={{ ...selectStyle, flex: 1, fontSize: 13, padding: '8px 10px' }}
                    >
                      <option value="paid">Paid</option>
                      <option value="partial">Partial</option>
                      <option value="pending">Unpaid</option>
                    </select>
                    <Button size="sm" variant="primary"
                      loading={statusMutation.isPending}
                      onClick={handleStatusSave}>
                      Save
                    </Button>
                    <Button size="sm" variant="ghost"
                      onClick={() => setEditingStatus(false)}>
                      Cancel
                    </Button>
                  </div>
                )}
              </DrawerSection>

              {!editingStatus && (
                <div style={{ marginBottom: 20 }}>
                  <Button
                    variant="secondary" size="sm"
                    onClick={() => {
                      setNewStatus(displayStatus || 'paid');
                      setEditingStatus(true);
                    }}
                  >
                    Update Payment Status
                  </Button>
                </div>
              )}

              {items.length > 0 && (
                <DrawerSection title={`Line Items (${items.length})`}>
                  {items.map((item, idx) => (
                    <div key={item.sale_item_id || idx} style={{
                      padding: '11px 14px',
                      borderBottom: idx === items.length - 1 ? 'none' : '1px solid var(--border)',
                      display: 'flex', justifyContent: 'space-between',
                      alignItems: 'flex-start', gap: 12,
                    }}>
                      <div>
                        <div style={{ fontSize: 13, fontWeight: 600, color: 'var(--text-primary)' }}>
                          {item.product_name || 'Product'}
                        </div>
                        <div style={{ fontSize: 12, color: 'var(--text-muted)', marginTop: 3 }}>
                          {item.sale_item_quantity} × {formatCurrency(item.sale_item_unit_price)}
                          {Number(item.item_tax_total) > 0 &&
                            ` + ${formatCurrency(item.item_tax_total)} tax`}
                        </div>
                      </div>
                      <span style={{ fontSize: 13, fontWeight: 700,
                        color: 'var(--text-primary)', flexShrink: 0 }}>
                        {formatCurrency(item.item_total_with_tax)}
                      </span>
                    </div>
                  ))}
                </DrawerSection>
              )}

              {(cgst > 0 || sgst > 0 || igst > 0) && (
                <DrawerSection title="Tax Breakdown">
                  {cgst > 0 && <InfoRow label="CGST" value={formatCurrency(cgst)} />}
                  {sgst > 0 && <InfoRow label="SGST" value={formatCurrency(sgst)} />}
                  {igst > 0 && <InfoRow label="IGST" value={formatCurrency(igst)} isLast />}
                </DrawerSection>
              )}

              <DrawerSection title="Summary">
                <InfoRow label="Subtotal"   value={formatCurrency(subtotal)} />
                <InfoRow label="Tax Total"  value={formatCurrency(taxTotal)} />
                <InfoRow label="Total"
                  value={
                    <span style={{ fontWeight: 700, fontSize: 15, color: 'var(--text-primary)' }}>
                      {formatCurrency(finalAmount)}
                    </span>
                  }
                />
                {totalPaid > 0 && (
                  <InfoRow label="Amount Paid" value={formatCurrency(totalPaid)} />
                )}
                {remaining > 0 && (
                  <InfoRow label="Remaining" isLast
                    value={
                      <span style={{ color: '#ef4444', fontWeight: 600 }}>
                        {formatCurrency(remaining)}
                      </span>
                    }
                  />
                )}
              </DrawerSection>

              {(detail?.notes || sale.notes) && (
                <DrawerSection title="Notes">
                  <div style={{
                    padding: '11px 14px', fontSize: 13,
                    color: 'var(--text-secondary)', lineHeight: 1.6,
                  }}>
                    {detail?.notes || sale.notes}
                  </div>
                </DrawerSection>
              )}
            </>
          )}
        </div>
      </div>
    </>
  );
}

function DrawerSection({ title, children }) {
  return (
    <div style={{ marginBottom: 20 }}>
      <p style={{
        fontSize: 10.5, fontWeight: 700, textTransform: 'uppercase',
        letterSpacing: '0.08em', color: 'var(--text-muted)', margin: '0 0 10px',
      }}>
        {title}
      </p>
      <div style={{
        background: 'var(--bg-page)',
        border: '1px solid var(--border)',
        borderRadius: 12, overflow: 'hidden',
      }}>
        {children}
      </div>
    </div>
  );
}

function InfoRow({ icon, label, value, isLast = false }) {
  return (
    <div style={{
      display: 'flex', alignItems: 'center', gap: 10,
      padding: '10px 14px',
      borderBottom: isLast ? 'none' : '1px solid var(--border)',
    }}>
      {icon && (
        <span style={{ color: 'var(--text-muted)', flexShrink: 0 }}>
          {React.cloneElement(icon, { style: { width: 15, height: 15 } })}
        </span>
      )}
      <span style={{
        fontSize: 12.5, color: 'var(--text-muted)',
        minWidth: 120, fontWeight: 500, flexShrink: 0,
      }}>
        {label}
      </span>
      <span style={{
        fontSize: 13, color: 'var(--text-primary)',
        fontWeight: 500, flex: 1, textAlign: 'right',
      }}>
        {value}
      </span>
    </div>
  );
}