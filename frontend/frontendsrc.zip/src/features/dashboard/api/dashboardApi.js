// src/features/dashboard/api/dashboardApi.js
//
// FIX: Changed Promise.all → Promise.allSettled
//
// WHY:
//   Promise.all rejects immediately if ANY request fails.
//   Staff users get 403 on /expenses/ and (old) /stock/alerts.
//   One 403 caused the entire dashboard to show "⚠️ Could not load data".
//
//   Promise.allSettled waits for all requests to finish regardless.
//   Each result has { status: 'fulfilled' | 'rejected', value / reason }.
//   We safely extract data only from fulfilled requests.
//   Rejected requests (permission denied) simply contribute zero/empty values.
//
// RESULT:
//   Staff dashboard now loads correctly.
//   Metrics that staff can't see just show 0 instead of crashing the page.

import api from '../../../api/axios'

export async function fetchDashboardSummary() {
  // Fire all 5 requests in parallel — allSettled means one failure = no crash
  const [salesRes, customersRes, productsRes, alertsRes, expensesRes] =
    await Promise.allSettled([
      api.get('/sales/'),
      api.get('/customers/'),
      api.get('/products/'),
      api.get('/stock/alerts'),
      api.get('/expenses/'),
    ])

  // Helper: safely extract .data from a settled result
  // If the request failed (403 or network error), returns null
  const getData = (settled) =>
    settled.status === 'fulfilled' ? settled.value.data : null

  const salesData     = getData(salesRes)
  const customersData = getData(customersRes)
  const productsData  = getData(productsRes)
  const alertsData    = getData(alertsRes)
  const expensesData  = getData(expensesRes)

  const sales    = salesData?.items    || []
  const expenses = expensesData?.items || []
  const alerts   = alertsData?.items   || []

  return {
    totalRevenue:    sales.reduce((sum, s) => sum + parseFloat(s.sales_final_amount || 0), 0),
    totalInvoices:   salesData?.pagination?.total    || 0,
    totalCustomers:  customersData?.pagination?.total || 0,
    totalProducts:   productsData?.pagination?.total  || 0,
    pendingPayments: sales.filter(s => s.sales_payment_status === 'partial').length,
    lowStockAlerts:  alerts.filter(a => a.alert_status === 'unread').length,
    totalExpenses:   expenses.reduce((sum, e) => sum + parseFloat(e.expense_amount || 0), 0),
    recentSales:     sales.slice(0, 5),
  }
}