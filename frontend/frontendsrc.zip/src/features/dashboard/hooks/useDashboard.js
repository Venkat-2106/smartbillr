import { useQuery } from '@tanstack/react-query'
import { fetchDashboardSummary } from '../api/dashboardApi'

export function useDashboard() {
  return useQuery({
    queryKey: ['dashboard-summary'],
    queryFn: fetchDashboardSummary,
    staleTime: 1000 * 60, // cache for 60 seconds
  })
}