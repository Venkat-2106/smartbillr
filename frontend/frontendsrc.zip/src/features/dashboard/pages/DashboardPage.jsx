// src/features/dashboard/pages/DashboardPage.jsx
//
// CHANGE FROM EXISTING:
//   - Import useAuthStore hasPermission
//   - Financial cards (Total Revenue, Total Expenses) only rendered
//     when user has "dashboard.financial" permission
//   - Recent Sales table "Amount" column hidden unless "dashboard.financial"
//   - Everything else (design, layout, StatCard, Badge, Skeleton) unchanged

import { useDashboard } from '../hooks/useDashboard'
import useAuthStore from '../../../store/authStore'
import { formatCurrency } from '../../../shared/utils/formatCurrency'
import { formatDate } from '../../../shared/utils/formatDate'

// ─── Skeleton ─────────────────────────────────────────────────────────────────
function Skeleton({ w = '60%', h = 28 }) {
  return (
    <div style={{
      height: h, width: w,
      background: 'var(--bg-hover)',
      borderRadius: 6,
      animation: 'shimmer 1.5s ease-in-out infinite',
    }} />
  )
}

// ─── Stat Card ────────────────────────────────────────────────────────────────
function StatCard({ label, value, sub, icon, accent, loading }) {
  return (
    <div
      style={{
        background: 'var(--bg-card)',
        border: '1px solid var(--border)',
        borderRadius: 18,
        padding: '24px 22px 20px',
        display: 'flex',
        flexDirection: 'column',
        gap: 14,
        boxShadow: 'var(--shadow-card)',
        transition: 'transform 0.18s var(--ease-out), box-shadow 0.18s var(--ease-out), border-color 0.18s',
        minWidth: 0,
      }}
      onMouseEnter={e => {
        e.currentTarget.style.transform = 'translateY(-2px)'
        e.currentTarget.style.boxShadow = 'var(--shadow-md)'
        e.currentTarget.style.borderColor = 'var(--border-hover)'
      }}
      onMouseLeave={e => {
        e.currentTarget.style.transform = 'translateY(0)'
        e.currentTarget.style.boxShadow = 'var(--shadow-card)'
        e.currentTarget.style.borderColor = 'var(--border)'
      }}
    >
      {/* Icon */}
      <div style={{
        width: 42, height: 42, borderRadius: 12,
        background: accent + '18',
        border: '1px solid ' + accent + '28',
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        fontSize: 19,
        flexShrink: 0,
      }}>
        {icon}
      </div>

      {/* Value */}
      {loading
        ? <Skeleton w="70%" h={28} />
        : (
          <div style={{
            fontSize: 'clamp(17px, 2.2vw, 26px)',
            fontWeight: 800,
            color: 'var(--text-primary)',
            letterSpacing: '-0.5px',
            lineHeight: 1.1,
            overflow: 'hidden',
            textOverflow: 'ellipsis',
            whiteSpace: 'nowrap',
          }}>
            {value}
          </div>
        )
      }

      {/* Label + sub */}
      <div>
        <div style={{ fontSize: 13, fontWeight: 600, color: 'var(--text-primary)', marginBottom: 2 }}>
          {label}
        </div>
        <div style={{ fontSize: 12, color: 'var(--text-muted)', fontWeight: 400 }}>
          {sub}
        </div>
      </div>
    </div>
  )
}

// ─── Badge ────────────────────────────────────────────────────────────────────
function Badge({ status }) {
  const cfg = {
    paid:    { bg: 'var(--success-bg)', color: 'var(--success-text)', border: 'var(--success-border)', dot: '#22C55E', label: 'Paid' },
    partial: { bg: 'var(--warning-bg)', color: 'var(--warning-text)', border: 'var(--warning-border)', dot: '#F59E0B', label: 'Partial' },
    unpaid:  { bg: 'var(--danger-bg)',  color: 'var(--danger-text)',  border: 'var(--danger-border)',  dot: '#F43F5E', label: 'Unpaid' },
  }
  const c = cfg[status] || cfg.unpaid
  return (
    <span style={{
      display: 'inline-flex', alignItems: 'center', gap: 5,
      background: c.bg, color: c.color,
      border: '1px solid ' + c.border,
      padding: '3px 10px', borderRadius: 99,
      fontSize: 11.5, fontWeight: 600,
    }}>
      <span style={{ width: 5, height: 5, borderRadius: '50%', background: c.dot, flexShrink: 0 }} />
      {c.label}
    </span>
  )
}

// ─── Main Page ────────────────────────────────────────────────────────────────
export default function DashboardPage() {
  const { data, isLoading, isError } = useDashboard()
  const business      = useAuthStore(s => s.business)
  const hasPermission = useAuthStore(s => s.hasPermission)
  const country       = business?.business_country_code || 'IN'

  // Financial data is only visible to users with dashboard.financial permission.
  // admin has it. manager and staff do not.
  const canSeeFinancials = hasPermission('dashboard.financial')

  // ── KPI cards — always visible (dashboard.view) ──────────────────────────
  const kpiCards = [
    { label: 'Total Invoices',   value: data?.totalInvoices   ?? 0, sub: 'All invoices raised',  icon: '🧾', accent: '#0EA5E9' },
    { label: 'Customers',        value: data?.totalCustomers  ?? 0, sub: 'Active accounts',      icon: '👥', accent: '#10B981' },
    { label: 'Products',         value: data?.totalProducts   ?? 0, sub: 'Items in catalogue',   icon: '📦', accent: '#F59E0B' },
    { label: 'Pending Payments', value: data?.pendingPayments ?? 0, sub: 'Partial invoices',     icon: '⏳', accent: '#F97316' },
    { label: 'Low Stock Alerts', value: data?.lowStockAlerts  ?? 0, sub: 'Unread alerts',        icon: '⚠️', accent: '#EF4444' },
  ]

  // ── Financial cards — only admin (dashboard.financial) ───────────────────
  const financialCards = [
    { label: 'Total Revenue',  value: formatCurrency(data?.totalRevenue  || 0, country), sub: 'Gross from all invoices',  icon: '💰', accent: '#4F46E5' },
    { label: 'Total Expenses', value: formatCurrency(data?.totalExpenses || 0, country), sub: 'All recorded expenses',    icon: '📊', accent: '#8B5CF6' },
  ]

  // Show financial cards first (if allowed), then KPI cards
  const visibleCards = canSeeFinancials
    ? [...financialCards, ...kpiCards]
    : kpiCards

  // Recent Sales table columns — Amount column hidden without dashboard.financial
  const tableHeaders = canSeeFinancials
    ? ['Invoice No', 'Amount', 'Status', 'Date']
    : ['Invoice No', 'Status', 'Date']

  // Skeleton column widths match the headers
  const skeletonWidths = canSeeFinancials
    ? ['70%', '100px', '60px', '90px']
    : ['70%', '60px', '90px']

  return (
    <>
      <style>{`
        @keyframes shimmer {
          0%, 100% { opacity: 1 }
          50%       { opacity: 0.4 }
        }
      `}</style>

      {/* ── Page header ── */}
      <div style={{ marginBottom: 40 }}>
        <h1 style={{
          fontSize: 24, fontWeight: 800,
          color: 'var(--text-primary)',
          letterSpacing: '-0.5px', margin: '0 0 6px',
        }}>
          Overview
        </h1>
        <p style={{ fontSize: 13.5, color: 'var(--text-muted)', margin: 0, fontWeight: 400 }}>
          {business?.business_name || 'Your store'} · live summary
        </p>
      </div>

      {/* ── Error banner ── */}
      {isError && (
        <div style={{
          background: 'var(--danger-bg)',
          border: '1px solid var(--danger-border)',
          borderRadius: 12, padding: '13px 18px',
          color: 'var(--danger-text)',
          fontSize: 13.5, marginBottom: 32, fontWeight: 500,
        }}>
          ⚠️ Could not load data. Make sure the backend is running, then refresh.
        </div>
      )}

      {/* ── Stat cards grid ── */}
      <div style={{
        display: 'grid',
        gridTemplateColumns: 'repeat(auto-fill, minmax(200px, 1fr))',
        gap: 16,
        marginBottom: 40,
      }}>
        {visibleCards.map(card => (
          <StatCard key={card.label} {...card} loading={isLoading} />
        ))}
      </div>

      {/* ── Recent Sales header ── */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 14 }}>
        <h2 style={{
          fontSize: 15, fontWeight: 700,
          color: 'var(--text-primary)',
          margin: 0,
        }}>
          Recent Sales
        </h2>
        <span style={{
          fontSize: 11.5, fontWeight: 600,
          color: 'var(--text-secondary)',
          background: 'var(--bg-subtle)',
          border: '1px solid var(--border)',
          borderRadius: 99, padding: '2px 9px',
        }}>
          Last 5
        </span>
      </div>

      {/* ── Recent Sales table ── */}
      <div style={{
        background: 'var(--bg-card)',
        border: '1px solid var(--border)',
        borderRadius: 18,
        boxShadow: 'var(--shadow-card)',
        overflow: 'hidden',
      }}>
        <div style={{ overflowX: 'auto' }}>
          <table style={{ width: '100%', borderCollapse: 'collapse' }}>
            <thead>
              <tr style={{
                background: 'var(--bg-subtle)',
                borderBottom: '1px solid var(--border)',
              }}>
                {tableHeaders.map(h => (
                  <th key={h} style={{
                    padding: '12px 24px',
                    textAlign: 'left',
                    fontSize: 10.5, fontWeight: 700,
                    color: 'var(--text-muted)',
                    letterSpacing: '0.08em',
                    textTransform: 'uppercase',
                    whiteSpace: 'nowrap',
                  }}>
                    {h}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {isLoading ? (
                [...Array(5)].map((_, i) => (
                  <tr key={i} style={{ borderBottom: '1px solid var(--border)' }}>
                    {skeletonWidths.map((w, j) => (
                      <td key={j} style={{ padding: '16px 24px' }}>
                        <Skeleton w={w} h={13} />
                      </td>
                    ))}
                  </tr>
                ))
              ) : !data?.recentSales?.length ? (
                <tr>
                  <td colSpan={tableHeaders.length} style={{
                    padding: '56px 24px', textAlign: 'center',
                    color: 'var(--text-muted)', fontSize: 13.5,
                  }}>
                    No sales yet. Create your first invoice to see it here.
                  </td>
                </tr>
              ) : (
                data.recentSales.map((sale, i) => (
                  <tr
                    key={sale.sales_id}
                    style={{
                      borderBottom: i < data.recentSales.length - 1
                        ? '1px solid var(--border)' : 'none',
                      transition: 'background 0.13s',
                    }}
                    onMouseEnter={e => e.currentTarget.style.background = 'var(--bg-subtle)'}
                    onMouseLeave={e => e.currentTarget.style.background = 'transparent'}
                  >
                    <td style={{
                      padding: '16px 24px',
                      fontSize: 13, fontWeight: 700,
                      color: 'var(--accent-600)',
                      letterSpacing: '0.01em',
                    }}>
                      {sale.invoice_no}
                    </td>

                    {/* Amount — only rendered for admin (dashboard.financial) */}
                    {canSeeFinancials && (
                      <td style={{
                        padding: '16px 24px',
                        fontSize: 13.5, fontWeight: 600,
                        color: 'var(--text-primary)',
                      }}>
                        {formatCurrency(parseFloat(sale.sales_final_amount), country)}
                      </td>
                    )}

                    <td style={{ padding: '16px 24px' }}>
                      <Badge status={sale.sales_payment_status} />
                    </td>
                    <td style={{
                      padding: '16px 24px',
                      fontSize: 12.5, color: 'var(--text-muted)', fontWeight: 400,
                    }}>
                      {formatDate(sale.sales_created_at)}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </>
  )
}